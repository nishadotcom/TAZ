function sharePopup(url){
    window.open(url , '123456789' , 'height=368,width=585,resizeable=yes');
	return false;
}